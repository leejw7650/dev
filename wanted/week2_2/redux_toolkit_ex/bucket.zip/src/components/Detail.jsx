import React, { useContext } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { BucketContext } from '../context/BucketContext';


const Detail = () => {
    const params = useParams();
    const {bucketList} = useContext(BucketContext);
    const navigate = useNavigate();

    return (
        <div>
            <h1>내 버킷 리스트</h1>
            <hr />
            <h3>상세 페이지입니다!</h3>
            <hr />
            <h5>나는 {params.bucket}을(를) 하고 싶어!</h5>
            <hr />
            <button onClick={() => {
                navigate('/');
            }}>back</button>
            <hr />
            <button onClick={() => {
                console.log(bucketList);
            }}> 현재 리스트 보기</button>
        </div>
    )
};

export default Detail;