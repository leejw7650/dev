import React, {useState} from 'react';

import InputList from './InputList';
import BucketBox from './BucketBox';

import { BucketContext } from '../context/BucketContext';

const Main = () => {
    const [bucketList, setBucketList] = useState([]);

    return (
        <BucketContext.Provider value={{bucketList, setBucketList}}>
            <div>
                <h1>내 버킷 리스트</h1>
                <hr />
                <InputList />
                <hr />
                {bucketList.map((bucket) => {
                    return (
                        <BucketBox bucket={bucket}/>
                    )
                    })}
            </div>
        </BucketContext.Provider>
    )
};

export default Main;