import { createContext } from "react";

export const BucketContext = createContext(null);