import React from "react";

const TaskList = (props) => {
    return (
        <div>
            {props.todoList.filter(task => !task.isDone).map((todo) => {
                return (
                    <div className='task-box'>
                        <h3>{todo.task}</h3>
                        <button onClick={() => {
                            const temp = [...props.todoList];
                            const taskInd = temp.findIndex(task => task.id === todo.id);
                            temp[taskInd].isDone = temp[taskInd].isDone? false : true;
                            console.log(temp);
                            props.setTodoList(temp);
                        }
                        }>complete</button>
                    </div>
                )
            })}
        </div>
    )
}

export default TaskList;